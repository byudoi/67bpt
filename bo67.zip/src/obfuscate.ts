import { exec } from 'child_process';
import tmp from 'tmp';
import path from 'path';
import fs from 'fs';

const PROMETHEUS_DIR = path.join(process.cwd(), 'prometheus');
const PROMETHEUS_CLI = path.join(PROMETHEUS_DIR, 'src', 'cli.lua');

const PRESET_MAP: Record<string, string> = {
    Weak: 'Weak',
    Medium: 'Medium',
    Strong: 'Strong',
};

function runCommand(cmd: string): Promise<void> {
    return new Promise((resolve, reject) => {
        exec(cmd, (error, stdout, stderr) => {
            if (error) reject(stderr || error.message);
            else resolve();
        });
    });
}

export default async function obfuscate(inputFile: string, preset: string): Promise<tmp.SynchrounousResult> {
    const prometheusPreset = PRESET_MAP[preset] || 'Weak';
    const outFile = tmp.fileSync({ postfix: '.lua' });

    await runCommand(
        `cd "${PROMETHEUS_DIR}" && lua "src/cli.lua" --preset ${prometheusPreset} --out "${outFile.name}" "${inputFile}"`
    );

    if (!fs.existsSync(outFile.name) || fs.readFileSync(outFile.name).length === 0) {
        throw new Error('Obfuscation failed or produced empty output.');
    }

    return outFile;
}
